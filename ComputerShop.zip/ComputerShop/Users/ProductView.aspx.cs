﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Users_ProductView : System.Web.UI.Page
{
    public static String DatabaseConnection = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if(Session["Username"] != null)
        {
            if (!IsPostBack)
            {
                BindProductImageSliderReapter();
                BindProductDetailsrReapter();
            }

        }
        else
         {
                Response.Redirect("~/Users/Default.aspx");
         }
        
        
    }

    private void BindProductDetailsrReapter()
    {
        Int64 ProductID = Convert.ToInt64(Request.QueryString["ProductID"]);
        try
        {
            SqlConnection con = new SqlConnection(DatabaseConnection);
            con.Open();
            SqlCommand cmd = new SqlCommand("select *from tblProducts where ProductID='" + ProductID + "'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                rptrProductViewDetails.DataSource = dt;
                rptrProductViewDetails.DataBind();
            }

            con.Close();

        }

        catch (Exception ex)
        {
            Response.Write("Expectation Error." + ex);

        }
    }

    private void BindProductImageSliderReapter()
    {
        Int64 ProductID = Convert.ToInt64(Request.QueryString["ProductID"]);
        try
        {
            SqlConnection con = new SqlConnection(DatabaseConnection);
            con.Open();
            SqlCommand cmd = new SqlCommand("select *from tblProductImages where ProductID='"+ ProductID + "'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                rptrProductViewSlider.DataSource = dt;
                rptrProductViewSlider.DataBind();
            }
           
            con.Close();

        }

        catch (Exception ex)
        {
            Response.Write("Expectation Error." + ex);

        }
    }

    protected string GetActiveImageClass(int ItemIndex)
    {
        if (ItemIndex == 0)
        {
            return "active";
        }
        else
        {
            return "";
        }
    }




    protected void btnAddCart_Click(object sender, EventArgs e)
    {
        Int64 ProductID = Convert.ToInt64(Request.QueryString["ProductID"]);
        if (Request.Cookies["CartPID"] != null)
        {

            //Response.Cookies["CartPID"].Value = ProductID.ToString();
            //Response.Cookies["CartPID"].Expires = DateTime.Now.AddDays(1);
            string CookiePID = Request.Cookies["CartPID"].Value.Split('=')[1];
            CookiePID = CookiePID + "," + ProductID;
            HttpCookie CartProducts = new HttpCookie("CartPID");
            CartProducts.Values["CartPID"] = CookiePID;
            CartProducts.Expires = DateTime.Now.AddDays(7);
            Response.Cookies.Add(CartProducts);
        }
        else
        {
            //Response.Cookies["CartPID"].Value = Response.Cookies["CartPID"].Value+"|"+ProductID.ToString();
            //Response.Cookies["CartPID"].Expires = DateTime.Now.AddDays(1);

            HttpCookie CartProducts = new HttpCookie("CartPID");
            CartProducts.Values["CartPID"] = ProductID.ToString();
            CartProducts.Expires = DateTime.Now.AddDays(7);
            Response.Cookies.Add(CartProducts);
        }
       
        Response.Redirect("ProductView.aspx?ProductID=" + ProductID);
    }
}