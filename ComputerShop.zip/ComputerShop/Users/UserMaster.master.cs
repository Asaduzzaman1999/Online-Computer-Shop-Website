﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Users_UserMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        BindCartNumber();
        if (Session["Username"] != null)
        {
            btnLoginMaster.Visible = false;
            btnLogOutMaster.Visible = true;
        }
        else
        {
            btnLoginMaster.Visible = true;
            btnLogOutMaster.Visible = false;
        }
    }
    public void BindCartNumber()
    {
       
        if (Request.Cookies["CartPID"] != null)
        {
            string CookiePID = Request.Cookies["CartPID"].Value.Split('=')[1];
            string[] ProductArray = CookiePID.Split(',');
            int ProductCount = ProductArray.Length;
            productCount.InnerText = ProductCount.ToString();
         
        }
        else
        {
            productCount.InnerText = 0.ToString();
        }
    }


    protected void btnLoginMaster_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Users/Login.aspx");
    }

    protected void btnLogOutMaster_Click(object sender, EventArgs e)
    {
        Session["Username"] = null;
        Session.RemoveAll();
        Response.Redirect("~/Users/Default.aspx");
    }

   
}
