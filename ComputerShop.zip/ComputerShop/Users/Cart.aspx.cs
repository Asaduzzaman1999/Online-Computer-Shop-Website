﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Users_Cart : System.Web.UI.Page
{
    public static String DatabaseConnection = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] != null)
        {
            if (!IsPostBack)
            {
                
                BindProductCart();
            }

        }
        else
        {
            Response.Redirect("~/Users/Login.aspx");
        }
    }

    private void BindProductCart()
    {
        if (Request.Cookies["CartPID"] != null)
        {
            DataTable dt = new DataTable();
            string CookieData = Request.Cookies["CartPID"].Value.Split('=')[1];
            string[] CookieDataArray = CookieData.Split(',');
            if (CookieDataArray.Length > 0)
            {
                NoProductFound.Visible = false;
                h2NoItems.InnerHtml = "My Shopping Cart:(" + CookieDataArray.Length + " items)";
                Int64 CartTotal = 0;
                Int64 Total = 0;
                for (int i=0; i < CookieDataArray.Length; i++)
                {
                    string ProductID = CookieDataArray[i].ToString().Split('-')[0];
                    try
                    {
                        SqlConnection con = new SqlConnection(DatabaseConnection);
                        con.Open();
                        SqlCommand cmd = new SqlCommand("select A.*,B.*from tblProducts A cross apply(select top 1 *from tblProductImages B where B.ProductID=A.ProductID )B where A.ProductID='" + ProductID + "'", con);
                        cmd.CommandType = CommandType.Text;
                        SqlDataAdapter sda = new SqlDataAdapter(cmd); 
                        sda.Fill(dt);
                        con.Close();
                        CartTotal += Convert.ToInt64(dt.Rows[i]["ProductPrice"]);
                        Total += Convert.ToInt64(dt.Rows[i]["ProductSellPrice"]);
                    }

                    catch (Exception ex)
                    {
                        Response.Write("Expectation Error." + ex);

                    }
                    //try
                    //{
                    //    CartTotal += Convert.ToInt64(dt.Rows[i]["ProductPrice"]);
                    //    Total += Convert.ToInt64(dt.Rows[i]["ProductSellPrice"]);
                    //}
                    //catch
                    //{
                    //    h2NoItems.InnerHtml = "Your Shopping Cart is Empty";
                    //    divPriceDetails.Visible = false;
                    //    NoProductFound.Visible = true;
                    //}
                }
                rpteCartProducts.DataSource = dt;
                rpteCartProducts.DataBind();
                spanCartTotal.InnerHtml = "Rs. "+CartTotal.ToString()+ "/=";
                spanTotal.InnerHtml = "Rs. " + Total.ToString() + "/=";
                spanDiscount.InnerHtml = "-" + (CartTotal- Total).ToString() + "/=";
            }
            else
            {
                h2NoItems.InnerHtml = "Your Shopping Cart is Empty";
                divPriceDetails.Visible = false;
                NoProductFound.Visible = true;
            }
           
            
        }
        else
        {
            h2NoItems.InnerHtml = "Your Shopping Cart is Empty";
            divPriceDetails.Visible = false;
            NoProductFound.Visible = true;
        }
    }

    protected void btnRemoveProduct_Click(object sender, EventArgs e)
    {
        string CookieProductID = Request.Cookies["CartPID"].Value.Split('=')[1];
        List<string> CookieProductIDList = CookieProductID.Split(',').Select(i => i.Trim()).Where(i => i != string.Empty).ToList();
        CookieProductIDList.Remove(CookieProductID);
        string CookieProductIDUpdated = string.Join(",", CookieProductIDList.ToArray());
        if (CookieProductIDUpdated == "")
        {
            HttpCookie CartProduct = Request.Cookies["CartPID"];
            CartProduct.Values["CartPID"] = null;
            CartProduct.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(CartProduct);
        }
        else
        {
            HttpCookie CartProduct = Request.Cookies["CartPID"];
            CartProduct.Values["CartPID"] = null;
            CartProduct.Expires = DateTime.Now.AddDays(7);
            Response.Cookies.Add(CartProduct);
        }
        Response.Redirect("~/Users/Cart.aspx");
    }
}