﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Users_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

        if (!IsPostBack)
        {
            if (Request.Cookies["Uemail"] != null && Request.Cookies["Upass"] != null)
            {
                txtEmail.Text = Request.Cookies["Uemail"].Value;
                txtPass.Text = Request.Cookies["Upass"].Value;
                chkRemember.Checked = true;
            }
        }
    }
   
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (IsLoginFormValidated())
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("Select *from tblUser where UEmail=@email and UPassword=@password", con);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@password", txtPass.Text);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    if (chkRemember.Checked)
                    {
                        Response.Cookies["Uemail"].Value = txtEmail.Text;
                        Response.Cookies["Upass"].Value = txtPass.Text;
                        Response.Cookies["Uemail"].Expires = DateTime.Now.AddMonths(3);
                        Response.Cookies["Upass"].Expires = DateTime.Now.AddMonths(3);
                    }
                    else
                    {
                        Response.Cookies["Uemail"].Expires = DateTime.Now.AddMonths(-1);
                        Response.Cookies["Upass"].Expires = DateTime.Now.AddMonths(-1);
                    }

                    string userType;
                    userType = dt.Rows[0][7].ToString().Trim();
                    if (userType == "User")
                    {
                        Session["Username"] = txtEmail.Text;
                        Response.Redirect("UserHome.aspx");
                    }
                    else if (userType == "Admin")
                    {
                        Session["Username"] = txtEmail.Text;
                        Response.Redirect("~/Admin/AdminHome.aspx");
                    }

                }
                else
                {
                    lblLoginError.Text = "Invalid Username and Password";
                }
                clear();
                con.Close();

            }
            catch (Exception ex)
            {
                lblLoginError.Text = "Exception Error" + ex;
                lblLoginError.ForeColor = System.Drawing.Color.Red;
                txtEmail.Focus();

            }

        }

        else
        {
            txtEmail.Focus();
        }
    }
    public bool IsLoginFormValidated()
    {
        string Email = txtEmail.Text;
        string Pass = txtPass.Text;



        if (Email == "" && Pass == "")
        {
            lblEmailBlank.Text = "*";
            lblEmailBlank.ForeColor = System.Drawing.Color.Red;

            lblPasswordBlank.Text = "*";
            lblPasswordBlank.ForeColor = System.Drawing.Color.Red;


            txtEmail.Focus();
            return false;
        }


        else if (Email == "")
        {
            lblEmailBlank.Text = "*";
            lblEmailBlank.ForeColor = System.Drawing.Color.Red;
            txtEmail.Focus();
            return false;
        }
        else if (Pass == "")
        {
            lblPasswordBlank.Text = "*";
            lblPasswordBlank.ForeColor = System.Drawing.Color.Red;
            txtPass.Focus();
            return false;
        }
        else if (Pass.Length < 4 || Pass.Length > 25)
        {
            lblPasswordBlank.Text = "*";
            lblPasswordBlank.ForeColor = System.Drawing.Color.Red;
            txtPass.Focus();
            return false;
        }



        else
        {
            return true;
        }

    }
    private void clear()
    {

        txtEmail.Text = string.Empty;
        txtPass.Text = string.Empty;

    }

  
}