﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Users_UserHome : System.Web.UI.Page
{
    public static String DatabaseConnection = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["Username"] != null)
        {
            if (!IsPostBack)
            {
                BindProductReapter();
            }
        }
        else
        {
            Response.Redirect("~/Users/Default.aspx");
        }
        

        
            
       
    }

    private void BindProductReapter()
    {
        try
        {
            SqlConnection con = new SqlConnection(DatabaseConnection);
            con.Open();
            SqlCommand cmd = new SqlCommand("sp_BindAllProducts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                rptrProducts.DataSource = dt;
                rptrProducts.DataBind(); 
            }
            else
            {
                lblProductNotAvailable.Text = "Products are not available";
            }
            con.Close();

        }

        catch (Exception ex)
        {
            Response.Write("Expectation Error." + ex);

        }
    }

   
}