﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Users_Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        if (IsRegistrationFormValidated())
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into tblUser (UFName,ULName,UEmail,UPassword,UCPassword,UUserName,UserType) values('" + txtFname.Text + "','" + txtLname.Text + "','" + txtEmail.Text + "','" + txtPass.Text + "','" + txtCpass.Text + "','" + txtFname.Text + "','User')", con);
                cmd.ExecuteNonQuery();
                clear();
                con.Close();
                Response.Redirect("~/Users/Login.aspx");
            }
            catch (Exception ex)
            {

                Response.Write(ex);
                txtFname.Focus();

            }
        }

        else
        {
            lblSignUpError.Text = "Validation Failed";
            lblSignUpError.ForeColor = System.Drawing.Color.Red;
            txtFname.Focus();
        }
    }

    public bool IsRegistrationFormValidated()
    {
        string FName = txtFname.Text;
        string LName = txtLname.Text;
        string Email = txtEmail.Text;
        string Pass = txtPass.Text;
        string Cpass = txtCpass.Text;


        if (FName == "" && LName == "" && Email == "" && Pass == "" && Cpass == "")
        {
            lblFnameBlank.Text = "**Fill First Name";
            lblFnameBlank.ForeColor = System.Drawing.Color.Red;

            lblLnameBlank.Text = "**Fill Last Name";
            lblLnameBlank.ForeColor = System.Drawing.Color.Red;

            lblEmailBlank.Text = "**Fill Email ";
            lblEmailBlank.ForeColor = System.Drawing.Color.Red;

            lblPasswordBlank.Text = "**Fill Password";
            lblPasswordBlank.ForeColor = System.Drawing.Color.Red;

            lblCPasswordBlank.Text = "**Fill Conform Password";
            lblCPasswordBlank.ForeColor = System.Drawing.Color.Red;
            txtFname.Focus();
            return false;
        }
        else if (FName == "")
        {
            lblFnameBlank.Text = "**Fill First Name";
            lblFnameBlank.ForeColor = System.Drawing.Color.Red;
            txtFname.Focus();
            return false;
        }
        else if (LName == "")
        {
            lblLnameBlank.Text = "**Fill Last Name";
            lblLnameBlank.ForeColor = System.Drawing.Color.Red;
            txtLname.Focus();
            return false;
        }
        else if (Email == "")
        {
            lblEmailBlank.Text = "**Fill Email ";
            lblEmailBlank.ForeColor = System.Drawing.Color.Red;
            txtEmail.Focus();
            return false;
        }
        else if (Pass == "")
        {
            lblPasswordBlank.Text = "**Fill Password";
            lblPasswordBlank.ForeColor = System.Drawing.Color.Red;
            txtPass.Focus();
            return false;
        }
        else if (Pass.Length < 4 || Pass.Length > 25)
        {
            lblPasswordBlank.Text = "**Invalid Length";
            lblPasswordBlank.ForeColor = System.Drawing.Color.Red;
            txtPass.Focus();
            return false;
        }

        else if (Pass != Cpass)
        {
            lblCPasswordBlank.Text = "**Conform Password Invalid";
            lblCPasswordBlank.ForeColor = System.Drawing.Color.Red;
            txtCpass.Focus();
            return false;
        }

        else
        {
            return true;
        }

    }

    private void clear()
    {
        txtFname.Text = string.Empty;
        txtLname.Text = string.Empty;
        txtEmail.Text = string.Empty;
        txtPass.Text = string.Empty;
        txtCpass.Text = string.Empty;
    }
}