﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Admin_AddCatagories : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            BindCategoryReapter();
        }
        else
        {
            txtAddCat.Focus();
        }
    }
    private void BindCategoryReapter()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select *from tblAddCatagory", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            rptrCategories.DataSource = dt;
            rptrCategories.DataBind();
            con.Close();

        }

        catch (Exception ex)
        {
            Response.Write("Expectation Error." + ex);
            txtAddCat.Focus();
        }
    }


    protected void btnAddCat_Click(object sender, EventArgs e)
    {
        if (IsLoginFormValidated())
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into tblAddCatagory (CatName) values('" + txtAddCat.Text + "')", con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Catagory Successfully Added.');</script>");
                txtAddCat.Text = string.Empty;
                txtAddCat.Focus();
            }

            catch (Exception ex)
            {
                Response.Write("Expectation Error." + ex);
                txtAddCat.Focus();
            }
        }
        else
        {
            txtAddCat.Focus();
        }
        BindCategoryReapter();
    }

    public bool IsLoginFormValidated()
    {
        string Cat = txtAddCat.Text;



        if (Cat == "")
        {
            lblCatBlank.Text = "";
            lblCatBlank.ForeColor = System.Drawing.Color.Red;
            txtAddCat.Focus();
            return false;
        }



        else
        {
            return true;
        }
    }
}
