﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class Admin_AddSubcatagories : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindMainCat();
            BindSubCategoryReapter();
        }
       
    }

    private void BindSubCategoryReapter()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select A.*,B.*from tblAddSubCatagory A inner join tblAddCatagory B on B.CatID=A.MainCatID", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            rptrSubCategories.DataSource = dt;
            rptrSubCategories.DataBind();
            con.Close();

        }

        catch (Exception ex)
        {
            Response.Write("Expectation Error." + ex);
            
        }
    }

    private void BindMainCat()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from tblAddCatagory", con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count != 0)
        {
            ddlMainCat.DataSource = dt;
            ddlMainCat.DataTextField = "CatName";
            ddlMainCat.DataValueField = "CatID";
            ddlMainCat.DataBind();
            ddlMainCat.Items.Insert(0, new ListItem("Select Catagory", "0"));
        }
        con.Close();
    }

    protected void btnAddSubCat_Click(object sender, EventArgs e)
    {
        if (IsLoginFormValidated())
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into tblAddSubCatagory (SubCatName,MainCatID) values('" + txtAddSubCat.Text + "','" + ddlMainCat.SelectedItem.Value + "')", con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Catagory Successfully Added.');</script>");
                txtAddSubCat.Text = string.Empty;
                ddlMainCat.ClearSelection();
                ddlMainCat.Items.FindByValue("0").Selected = true;
            }

            catch (Exception ex)
            {
                Response.Write("Expectation Error." + ex);
                txtAddSubCat.Focus();
            }

        }
        else
        {
            txtAddSubCat.Focus();
        }
        BindSubCategoryReapter();
    }

    public bool IsLoginFormValidated()
    {
        string SubCat = txtAddSubCat.Text;
        string CatDropDown = ddlMainCat.Text;


        if (SubCat == "")
        {
            lblSubCatBlank.Text = "";
            lblSubCatBlank.ForeColor = System.Drawing.Color.Red;
            txtAddSubCat.Focus();
            return false;
        }

        else if (CatDropDown == "")
        {
            lblSubCatBlank.Text = "";
            lblSubCatBlank.ForeColor = System.Drawing.Color.Red;

            return false;
        }
        else if (CatDropDown == "-Select Catagory-")
        {
            lblSubCatBlank.Text = "-Select Catagory-";
            lblSubCatBlank.ForeColor = System.Drawing.Color.Red;

            return false;
        }

        else
        {
            return true;
        }
    }

}
