﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;

public partial class Admin_Add : System.Web.UI.Page
{
    public static String DatabaseConnection = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindBrand();
            BindCategory();
            ddlSubCategory.Enabled = false;
        }
    }
    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindSubCategory();
        

    }

    private void BindSubCategory()
    {
        try
        {
            SqlConnection con = new SqlConnection(DatabaseConnection);
            con.Open();
            SqlCommand cmd = new SqlCommand("select *from tblAddSubCatagory where MainCatID='"+ddlCategory.SelectedItem.Value+"'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                ddlSubCategory.DataSource = dt;
                ddlSubCategory.DataTextField = "SubCatName";
                ddlSubCategory.DataValueField = "SubCatID";
                ddlSubCategory.DataBind();
                ddlSubCategory.Items.Insert(0, new ListItem("Select Sub-Category", "0"));
                ddlSubCategory.Enabled = true;
            }
            else
            {
               
                ddlSubCategory.Enabled = false;
            }
            con.Close();

        }

        catch (Exception ex)
        {
            Response.Write("Expectation Error." + ex);

        }
    }

    private void BindCategory()
    { 
        try
        {
            SqlConnection con = new SqlConnection(DatabaseConnection);
            con.Open();
            SqlCommand cmd = new SqlCommand("select *from tblAddCatagory", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                ddlCategory.DataSource = dt;
                ddlCategory.DataTextField = "CatName";
                ddlCategory.DataValueField = "CatID";
                ddlCategory.DataBind();
                ddlCategory.Items.Insert(0, new ListItem("Select Category", "0"));
            }
            con.Close();

        }

        catch (Exception ex)
        {
            Response.Write("Expectation Error." + ex);

        }
        
    }

    private void BindBrand()
    {

        try
        {
            SqlConnection con = new SqlConnection(DatabaseConnection);
            con.Open();
            SqlCommand cmd = new SqlCommand("select *from tblAddBrands", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if(dt.Rows.Count!=0)
            {
                ddlBrand.DataSource = dt;
                ddlBrand.DataTextField = "BrandNmae";
                ddlBrand.DataValueField = "BrabdID";
                ddlBrand.DataBind();
                ddlBrand.Items.Insert(0, new ListItem("Select Brand", "0"));
            }
            con.Close();

        }

        catch (Exception ex)
        {
            Response.Write("Expectation Error." + ex);

        }
    }

    protected void btnAddProduct_Click(object sender, EventArgs e)
    {

        try
        {  //Code  For Products Table Starts Here
            SqlConnection con = new SqlConnection(DatabaseConnection);
            
            SqlCommand cmd = new SqlCommand("sp_AddProduct", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ProductName", txtProductName.Text);
            cmd.Parameters.AddWithValue("@ProductPrice", txtPrice.Text);
            cmd.Parameters.AddWithValue("@ProductSellPrice", txtSellingPrice.Text);
            cmd.Parameters.AddWithValue("@ProductBrandID", ddlBrand.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@ProductCatdID", ddlCategory.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@ProductSubCatdID", ddlSubCategory.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@ProductDescription", txtProductDescription.Text);
            cmd.Parameters.AddWithValue("@ProductMatCare", txtMatCare.Text);
            if (chkFreeDelivery.Checked == true)
            {
                cmd.Parameters.AddWithValue("@FreeDelivery", 1.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@FreeDelivery", 0.ToString());
            }
            if (chk30DaysReturn.Checked == true)
            {
                cmd.Parameters.AddWithValue("@30DarysReturn", 1.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@30DarysReturn", 0.ToString());
            }
            if (chkCOD.Checked == true)
            {
                cmd.Parameters.AddWithValue("@COD", 1.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@COD", 0.ToString());
            }
            
            con.Open();
            //Code  For Products Table Ends Here

            //Code  For Quantity Table Starts Here
            Int64 ProductID = Convert.ToInt64(cmd.ExecuteScalar());
            int Quantity = Convert.ToInt32(txtProductQuantity.Text);
            SqlCommand cmd2 = new SqlCommand("insert into tblProductQuantity (ProductID,ProductQuantity) values ('"+ ProductID + "','"+ Quantity + "')", con);
            cmd2.ExecuteNonQuery();
            //Code  For Quantity Table Ends Here

            //Code  For Image  Table Starts Here
            if (fuImg01.HasFile)
            {
                string savePath = Server.MapPath("~/Images/ProductImages/") + ProductID;
                if (!Directory.Exists(savePath))
                {
                    Directory.CreateDirectory(savePath);
                }
                string Extension = Path.GetExtension(fuImg01.PostedFile.FileName);
                fuImg01.SaveAs(savePath+"\\"+txtProductName.Text.ToString().Trim()+"01"+Extension);
                SqlCommand cmd3 = new SqlCommand("insert into tblProductImages values('"+ProductID+"','"+ txtProductName.Text.ToString().Trim() + "01"+ "','"+Extension+"')", con);
                cmd3.ExecuteNonQuery();
            }
            if (fuImg02.HasFile)
            {
                string savePath = Server.MapPath("~/Images/ProductImages/") + ProductID;
                if (!Directory.Exists(savePath))
                {
                    Directory.CreateDirectory(savePath);
                }
                string Extension = Path.GetExtension(fuImg01.PostedFile.FileName);
                fuImg02.SaveAs(savePath + "\\" + txtProductName.Text.ToString().Trim() + "02" + Extension);
                SqlCommand cmd4 = new SqlCommand("insert into tblProductImages values('" + ProductID + "','" + txtProductName.Text.ToString().Trim() + "02" + "','" + Extension + "')", con);
                cmd4.ExecuteNonQuery();
            }
            if (fuImg03.HasFile)
            {
                string savePath = Server.MapPath("~/Images/ProductImages/") + ProductID;
                if (!Directory.Exists(savePath))
                {
                    Directory.CreateDirectory(savePath);
                }
                string Extension = Path.GetExtension(fuImg01.PostedFile.FileName);
                fuImg03.SaveAs(savePath + "\\" + txtProductName.Text.ToString().Trim() + "03" + Extension);
                SqlCommand cmd5 = new SqlCommand("insert into tblProductImages values('" + ProductID + "','" + txtProductName.Text.ToString().Trim() + "03" + "','" + Extension + "')", con);
                cmd5.ExecuteNonQuery();
            }
            if (fuImg04.HasFile)
            {
                string savePath = Server.MapPath("~/Images/ProductImages/") + ProductID;
                if (!Directory.Exists(savePath))
                {
                    Directory.CreateDirectory(savePath);
                }
                string Extension = Path.GetExtension(fuImg01.PostedFile.FileName);
                fuImg04.SaveAs(savePath + "\\" + txtProductName.Text.ToString().Trim() + "04" + Extension);
                SqlCommand cmd6 = new SqlCommand("insert into tblProductImages values('" + ProductID + "','" + txtProductName.Text.ToString().Trim() + "04" + "','" + Extension + "')", con);
                cmd6.ExecuteNonQuery();
            }
            if (fuImg05.HasFile)
            {
                string savePath = Server.MapPath("~/Images/ProductImages/") + ProductID;
                if (!Directory.Exists(savePath))
                {
                    Directory.CreateDirectory(savePath);
                }
                string Extension = Path.GetExtension(fuImg01.PostedFile.FileName);
                fuImg05.SaveAs(savePath + "\\" + txtProductName.Text.ToString().Trim() + "05" + Extension);
                SqlCommand cmd7 = new SqlCommand("insert into tblProductImages values('" + ProductID + "','" + txtProductName.Text.ToString().Trim() + "05" + "','" + Extension + "')", con);
                cmd7.ExecuteNonQuery();
            }
                if (fuImg06.HasFile)
                {
                    string savePath = Server.MapPath("~/Images/ProductImages/") + ProductID;
                    if (!Directory.Exists(savePath))
                    {
                        Directory.CreateDirectory(savePath);
                    }
                    string Extension = Path.GetExtension(fuImg01.PostedFile.FileName);
                    fuImg06.SaveAs(savePath + "\\" + txtProductName.Text.ToString().Trim() + "06" + Extension);
                    SqlCommand cmd8 = new SqlCommand("insert into tblProductImages values('" + ProductID + "','" + txtProductName.Text.ToString().Trim() + "06" + "','" + Extension + "')", con);
                    cmd8.ExecuteNonQuery();
                }

          
            //Code  For Image Table Ends Here
            con.Close();
            Response.Write("<script>alert('Product Successfully Added.');</script>");
            clear();

        }

        catch (Exception ex)
        {
            Response.Write("Expectation Error." + ex);

        }
    }


    private void clear()
    {
        txtProductName.Text = string.Empty;
        txtPrice.Text = string.Empty;
        txtSellingPrice.Text = string.Empty;
        //ddlBrand.Text = string.Empty;
        //ddlCategory.Text = string.Empty;
        //ddlSubCategory.Text = string.Empty;
        txtProductDescription.Text = string.Empty;
        txtProductQuantity.Text = string.Empty;
        txtMatCare.Text = string.Empty;
    }

}