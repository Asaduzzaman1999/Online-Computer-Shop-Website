﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class Admin_AddBrand : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //BindBrandReapter();
            //GridView1.DataSource = SqlDataSource1;
            //GridView1.DataBind();
        }
        else
        {
            txtAddBrand.Focus();
        }
    }

    //private void BindBrandReapter()
    //{
    //    try
    //    {
    //        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
    //        con.Open();
    //        SqlCommand cmd = new SqlCommand("select *from tblAddBrands", con);
    //        SqlDataAdapter sda = new SqlDataAdapter(cmd);
    //        DataTable dt = new DataTable();
    //        sda.Fill(dt);
    //        rptrBrands.DataSource = dt;
    //        rptrBrands.DataBind();
    //        con.Close();
            
    //    }

    //    catch (Exception ex)
    //    {
    //        Response.Write("Expectation Error." + ex);
    //        txtAddBrand.Focus();
    //    }
    //}

    protected void btnAddBrand_Click(object sender, EventArgs e)
    {
        if (IsLoginFormValidated())
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into tblAddBrands (BrandNmae) values('" + txtAddBrand.Text + "')", con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Brand Successfully Added.');</script>");
                txtAddBrand.Text = string.Empty;
                txtAddBrand.Focus();
            }
            
            catch (Exception ex)
            {
                Response.Write ("Expectation Error." + ex);
                txtAddBrand.Focus();
            }
        }
        else
        {
            txtAddBrand.Focus();
        }
        //BindBrandReapter();
    }

    public bool IsLoginFormValidated()
    {
        string Brand = txtAddBrand.Text;



        //if (Brand == "")
        //{
        //    lblBrandBlank.Text = "";
        //    lblBrandBlank.ForeColor = System.Drawing.Color.Red;
        //    txtAddBrand.Focus();
        //    return false;
        //}
        return true;


        //else
        //{
        //    return true;
        //}
    }



    //protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    //{
    //    GridView1.EditIndex = e.NewEditIndex;
    //    GridView1.DataSource = SqlDataSource1;
    //    GridView1.DataBind();
    //    GridView1.EditRowStyle.BackColor = System.Drawing.Color.Orange;
    //}

    //protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    //{
    //    GridView1.EditIndex = -1;
    //    GridView1.DataSource = SqlDataSource1;
    //    GridView1.DataBind();
    //}

    //protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    //{
    //    TextBox BrandId = GridView1.Rows[e.RowIndex].FindControl("Label1");
    //    TextBox BrandName = GridView1.Rows[e.RowIndex].FindControl("TextBox1") as TextBox;
    //    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString);
    //    String updatedata = "update tblAddBrands set='" + BrandName.Text + "' where BrandId='" + BrandId.Text + "'";
    //    con.Open();

    //}
}