




----------------Drop All Tables And Procedures--------------
drop table tblUser;
drop table tblAddBrands;
drop table tblAddCatagory;
drop table tblAddSubCatagory;
drop table tblProducts;
drop procedure sp_AddProduct;
drop procedure sp_BindAllProducts;
drop table tblProductImages;
drop table tblProductQuantity;

-----------------Select All Tables ---------------
select *from tblUser;
select *from tblAddBrands;
select *from tblAddCatagory;
select *from tblAddSubCatagory;
select *from tblProducts;
select *from tblProductImages;
select *from tblProductQuantity;

------------------Important Query-----------
select A.*,B.*from tblAddSubCatagory A inner join tblAddCatagory B on B.CatID=A.MainCatID;
ALTER TABLE tblProducts
DROP COLUMN ProductDetails;
delete from tblProducts where ProductID=2;
delete from tblProductQuantity where ProductID=2;
UPDATE tblProducts
SET ProductID=1
WHERE ProductID=3;
--------------Create All Tables And procedures-------------
create table tblUser
(
Uid int identity(1,1) primary key not null,
UFName nvarchar(50),
ULName nvarchar(50),
UEmail nvarchar(50),
UPassword nvarchar(50),
UCPassword nvarchar(50),
UUserName nvarchar(50),
UserType nvarchar(50)
)



create table tblAddBrands
(
BrabdID int identity(1,1) primary key not null,
BrandNmae nvarchar(50)
)




create table tblAddCatagory
(
CatID int identity(1,1) primary key not null,
CatName nvarchar(50)
)






create table tblAddSubCatagory
(
SubCatID int identity(1,1) primary key not null,
SubCatName nvarchar(50),
MainCatID int null,
constraint [FK_tblAddSubCatagory_tblAddCatagory] FOREIGN KEY ([MainCatID]) REFERENCES [tblAddCatagory] ([CatID])
)



create table tblProducts
(
ProductID int identity(1,1) primary key not null,
ProductName nvarchar(MAX),
ProductPrice money,
ProductSellPrice money,
ProductBrandID int,
ProductCatdID int,
ProductSubCatdID int,
ProductDescription nvarchar(MAX),
ProductMatCare nvarchar(MAX),
FreeDelivery int,
[30DarysReturn] int,
COD int,
constraint [FK_tblProducts_tblAddBrands] FOREIGN KEY ([ProductBrandID]) REFERENCES [tblAddBrands] ([BrabdID]),
constraint [FK_tblProducts_tblAddCatagory] FOREIGN KEY ([ProductCatdID]) REFERENCES [tblAddCatagory] ([CatID]),
constraint [FK_tblProducts_tblAddSubCatagory] FOREIGN KEY ([ProductSubCatdID]) REFERENCES [tblAddSubCatagory] ([SubCatID])
)


create procedure sp_AddProduct
(
	@ProductName nvarchar(MAX),
	@ProductPrice money,
	@ProductSellPrice money,
	@ProductBrandID int,
	@ProductCatdID int,
	@ProductSubCatdID int,
	@ProductDescription nvarchar(MAX),
	@ProductMatCare nvarchar(MAX),
	@FreeDelivery int,
	@30DarysReturn int,
	@COD int
)
as

begin
insert into tblProducts (ProductName,ProductPrice,ProductSellPrice,ProductBrandID,ProductCatdID,
ProductSubCatdID,ProductDescription,ProductMatCare,FreeDelivery,[30DarysReturn],
COD) values (@ProductName,@ProductPrice,@ProductSellPrice,@ProductBrandID,@ProductCatdID,
@ProductSubCatdID,@ProductDescription,@ProductMatCare,@FreeDelivery,@30DarysReturn,@COD)
select SCOPE_IDENTITY();
end

create procedure sp_BindAllProducts
As
select A.*,B.*,C.BrandNmae,A.ProductPrice-A.ProductSellPrice as DiscountAmmount from tblProducts A
inner join tblAddBrands C on C.BrabdID=A.ProductBrandID
cross apply(
select Top 1 *from tblProductImages B where B.ProductID=A.ProductID order by B.ProductID desc
)B
order by A.ProductID desc

return 0


create table tblProductImages
(
ProductImageID int identity(1,1) primary key not null,
ProductID int,
ImageName nvarchar(MAX),
ImageExtension nvarchar(100),
constraint [FK_tblProductImages_tblProducts] FOREIGN KEY ([ProductID]) REFERENCES [tblProducts] ([ProductID])
)


create table tblProductQuantity
(
ProductQuantityID int identity(1,1) primary key not null,
ProductID int,
ProductQuantity int,
constraint [FK_tblProductQuantity_tblProducts] FOREIGN KEY ([ProductID]) REFERENCES [tblProducts] ([ProductID])
)
