

---------------Create Table-------------

drop table TBL_APPLICANT_personal;
drop procedure sp_insertUser;
drop table tbl_department;
drop table tbl_ssc;
drop table tbl_hsc;
drop table tbl_grad;
drop table tbl_mas;


create table tbl_department
(
dept_id int identity primary key,
dept_name nvarchar(50) not null unique

)

insert into tbl_department
values('IT')
insert into tbl_department
values('ACCOUNTS')
insert into tbl_department
values('MANAGEMENT')
insert into tbl_department
values('HR')
insert into tbl_department
values('NETWROK SUPPORT')


SELECT * FROM tbl_department


SELECT * FROM TBL_APPLICANT_personal

CREATE TABLE TBL_APPLICANT_personal
(
ap_id int identity primary key,
ap_name nvarchar(100) not null,
ap_password nvarchar(20) NOT NULL,
ap_cninc nvarchar(30) not null unique,
ap_phone1 nvarchar(30) not null unique,
ap_phone2 nvarchar(30) not null ,
ap_email nvarchar(30) not null unique,
ap_image nvarchar(max) not null ,
ap_gender int,
ap_dob date
)
SELECT * FROM tbl_ssc;
SELECT * FROM tbl_hsc;
SELECT * FROM tbl_grad;
SELECT * FROM tbl_mas;

create table tbl_ssc
(
ssc_id int identity primary key,
ssc_percentage float, 
ssc_institue nvarchar(100) not null,
ssc_doc nvarchar(max) ,
ssc_fk_ap_id int foreign key references TBL_APPLICANT_personal(ap_id)
)
insert into tbl_ssc
values(90,'abc school and college','~/Upload/asad.doc',1)

insert into tbl_hsc
values(83,'abc school and college','~/Upload/asad.doc',1)

insert into tbl_grad
values(80,'abc University','~/Upload/asad.doc',1)

insert into tbl_mas
values(76,'abc University','~/Upload/asad.doc',1)


create table tbl_hsc
(
hsc_id int identity primary key,
hsc_percentage float, 
hsc_institue nvarchar(100) not null,
hsc_doc nvarchar(max) ,
hsc_fk_ap_id int foreign key references TBL_APPLICANT_personal(ap_id)

)



create table tbl_grad
(
grad_id int identity primary key,
grad_percentage float, 
grad_institue nvarchar(100) not null,
grad_doc nvarchar(max) ,
grad_fk_ap_id int foreign key references TBL_APPLICANT_personal(ap_id)
)

create table tbl_mas
(
mas_id int identity primary key,
mas_percentage float, 
mas_institue nvarchar(100) not null,
mas_doc nvarchar(max) ,
mas_fk_ap_id int foreign key references TBL_APPLICANT_personal(ap_id)
)


---------------create store procedure---------------------

create procedure sp_insertUser
(
@ap_name nvarchar(100) ,
@ap_password nvarchar(20),
@ap_cninc nvarchar(30) ,
@ap_phone1 nvarchar(30) ,
@ap_phone2 nvarchar(30) ,
@ap_email nvarchar(30),
@ap_image nvarchar(max)  ,
@ap_gender int,
@ap_dob date
)
as
 begin
 insert into TBL_APPLICANT_personal(ap_name,ap_password,ap_cninc,ap_phone1,ap_phone2,ap_email,ap_image,ap_gender,ap_dob)
 values
 (
@ap_name ,
@ap_password,
@ap_cninc  ,
@ap_phone1  ,
@ap_phone2  ,
@ap_email ,
@ap_image  ,
@ap_gender ,
@ap_dob 
 )
 end
 
 
create procedure sp_updatepersonaldetails
(
@ap_name nvarchar(100) ,
@ap_cninc nvarchar(30) ,
@ap_phone1 nvarchar(30) ,
@ap_phone2 nvarchar(30) ,
@ap_email nvarchar(30),
@ap_dob date,
@ap_id int
)as
 begin
	update TBL_APPLICANT_personal
	set ap_name=@ap_name,
	ap_cninc=@ap_cninc,
	@ap_phone1=@ap_phone1,
	@ap_phone2=@ap_phone2,
	@ap_email=@ap_email,
	@ap_dob=@ap_dob
	where ap_id=@ap_id
 end
 
 update tbl_ssc set ssc_percentage=89 where ssc_id=2;
 select *from tbl_ssc;
 
 create procedure sp_updateuserimage
 (
@ap_id int,
@ap_image nvarchar(max)
)as
 begin
	update TBL_APPLICANT_personal
	set ap_image=@ap_image
	where ap_id=@ap_id
 end
 
