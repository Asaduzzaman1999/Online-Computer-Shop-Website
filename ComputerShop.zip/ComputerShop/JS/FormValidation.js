﻿function LoginFormValidation() {

    var Email = document.getElementById("txtEmail").value;
    var Pass = document.getElementById("txtPass").value;

    if (Email == "" && Pass == "") {

        document.getElementById("lblEmailBlank").innerHTML = "*";
        document.getElementById("lblPasswordBlank").innerHTML = "*";

        document.getElementById("txtEmail").focus();
        return false;
    }

    else if (Email == "") {
        document.getElementById("lblEmailBlank").innerHTML = "*";
        document.getElementById("txtEmail").focus();
        return false;
    }
    else if (Pass == "") {
        document.getElementById("lblPasswordBlank").innerHTML = "*";
        document.getElementById("txtPass").focus();
        return false;
    }

    else if (Pass.length < 4) {
        document.getElementById("lblPasswordBlank").innerHTML = "*";
        document.getElementById("txtPass").focus();
        return false;
    }
    else if (Pass.length > 25) {
        document.getElementById("lblPasswordBlank").innerHTML = "*";
        document.getElementById("txtPass").focus();
        return false;
    }


    else {
        return true;
    }

}