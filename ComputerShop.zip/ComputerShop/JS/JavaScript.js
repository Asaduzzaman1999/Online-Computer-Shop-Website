﻿/*-------------------Slider Section (Dynamic) Starts Here-------------------------*/
setInterval(function () {
    if (document.getElementsByClassName("sliderItem")[0].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[1].classList.add("Active");
        document.getElementsByClassName("sliderItem")[0].classList.remove("Active");
    }
    else if (document.getElementsByClassName("sliderItem")[1].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[2].classList.add("Active");
        document.getElementsByClassName("sliderItem")[1].classList.remove("Active");
    }
    else if (document.getElementsByClassName("sliderItem")[2].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[3].classList.add("Active");
        document.getElementsByClassName("sliderItem")[2].classList.remove("Active");
    }
    else if (document.getElementsByClassName("sliderItem")[3].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[0].classList.add("Active");
        document.getElementsByClassName("sliderItem")[3].classList.remove("Active");
    } 

}, 5000);
/*-------------------Slider Section (Dynamic) Ends Here-------------------------*/


/*-------------------Slider Section (Static) Starts Here-------------------------*/

function next() {
    if (document.getElementsByClassName("sliderItem")[0].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[1].classList.add("Active");
        document.getElementsByClassName("sliderItem")[0].classList.remove("Active");
    }
    else if (document.getElementsByClassName("sliderItem")[1].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[2].classList.add("Active");
        document.getElementsByClassName("sliderItem")[1].classList.remove("Active");
    }
    else if (document.getElementsByClassName("sliderItem")[2].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[3].classList.add("Active");
        document.getElementsByClassName("sliderItem")[2].classList.remove("Active");
    }
    else if (document.getElementsByClassName("sliderItem")[3].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[0].classList.add("Active");
        document.getElementsByClassName("sliderItem")[3].classList.remove("Active");
    }

}
function previous() {
    if (document.getElementsByClassName("sliderItem")[3].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[2].classList.add("Active");
        document.getElementsByClassName("sliderItem")[3].classList.remove("Active");
    }
    else if (document.getElementsByClassName("sliderItem")[2].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[1].classList.add("Active");
        document.getElementsByClassName("sliderItem")[2].classList.remove("Active");
    }
    else if (document.getElementsByClassName("sliderItem")[1].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[0].classList.add("Active");
        document.getElementsByClassName("sliderItem")[1].classList.remove("Active");
    }
    else if (document.getElementsByClassName("sliderItem")[0].classList.contains("Active")) {
        document.getElementsByClassName("sliderItem")[3].classList.add("Active");
        document.getElementsByClassName("sliderItem")[0].classList.remove("Active");
    }
}
/*-------------------Slider Section (Static) Ends Here-------------------------*/

/*-------------------Back to Top Button starts Here-------------------------*/
const toTop = document.querySelector(".upButton");
window.addEventListener("scroll", () => {
    if (window.pageYOffset > 100) {
        toTop.classList.add("UpbtnActive");
    }
    else {
        toTop.classList.remove("UpbtnActive");
    }
})

/*-------------------Back to Top Button Ends Here-------------------------*/

/*-------------------Rsgistration Form Validation Starts Here-------------------------*/

function LoginFormValidation() {

    var Email = document.getElementById("txtEmail").value;
    var Pass = document.getElementById("txtPass").value;

    if (Email == "" && Pass == "") {

        document.getElementById("lblEmailBlank").innerHTML = "*";
        document.getElementById("lblPasswordBlank").innerHTML = "*";

        document.getElementById("txtEmail").focus();
        return false;
    }

    else if (Email == "") {
        document.getElementById("lblEmailBlank").innerHTML = "*";
        document.getElementById("txtEmail").focus();
        return false;
    }
    else if (Pass == "") {
        document.getElementById("lblPasswordBlank").innerHTML = "*";
        document.getElementById("txtPass").focus();
        return false;
    }

    else if (Pass.length < 4) {
        document.getElementById("lblPasswordBlank").innerHTML = "*";
        document.getElementById("txtPass").focus();
        return false;
    }
    else if (Pass.length > 25) {
        document.getElementById("lblPasswordBlank").innerHTML = "*";
        document.getElementById("txtPass").focus();
        return false;
    }


    else {
        return true;
    }

}


/*-------------------Rsgistration Form Validation Ends Here-------------------------*/